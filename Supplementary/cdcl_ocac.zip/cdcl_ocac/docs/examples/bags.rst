Theory of Bags
=================


.. api-examples::
    <examples>/api/cpp/bags.cpp
    <examples>/api/java/Bags.java
    <examples>/api/python/bags.py
    <examples>/api/smtlib/bags.smt2
