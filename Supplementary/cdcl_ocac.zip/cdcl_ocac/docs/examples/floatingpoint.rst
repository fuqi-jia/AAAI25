Theory of Floating-Points
======================================


.. api-examples::
    <examples>/api/cpp/floating_point_arith.cpp
    <examples>/api/java/FloatingPointArith.java
    <examples>/api/python/pythonic/floating_point.py
    <examples>/api/python/floating_point.py
