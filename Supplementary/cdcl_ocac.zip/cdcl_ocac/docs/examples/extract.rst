Theory of Bit-Vectors: :code:`extract`
======================================


.. api-examples::
    <examples>/api/cpp/extract.cpp
    <examples>/api/java/Extract.java
    <examples>/api/python/pythonic/extract.py
    <examples>/api/python/extract.py
    <examples>/api/smtlib/extract.smt2
