SyGuS: Grammars
===================


.. api-examples::
    <examples>/api/cpp/sygus-grammar.cpp
    <examples>/api/java/SygusGrammar.java
    <examples>/api/python/sygus-grammar.py
    <examples>/api/smtlib/sygus-grammar.sy

The utility method used for printing the synthesis solutions in the examples
above is defined separately in the ``utils`` module:

.. api-examples::
    <examples>/api/cpp/utils.h
    <examples>/api/cpp/utils.cpp
    <examples>/api/java/Utils.java
    <examples>/api/python/utils.py
