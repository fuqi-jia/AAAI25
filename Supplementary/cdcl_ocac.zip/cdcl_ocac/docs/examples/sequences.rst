Theory of Sequences
===================


.. api-examples::
    <examples>/api/cpp/sequences.cpp
    <examples>/api/java/Sequences.java
    <examples>/api/python/sequences.py
    <examples>/api/smtlib/sequences.smt2
