Theory of Bit-Vectors and Arrays
================================


.. api-examples::
    <examples>/api/cpp/bitvectors_and_arrays.cpp
    <examples>/api/java/BitVectorsAndArrays.java
    <examples>/api/python/pythonic/bitvectors_and_arrays.py
    <examples>/api/python/bitvectors_and_arrays.py
    <examples>/api/smtlib/bitvectors_and_arrays.smt2
