Theory of Sets
=================


.. api-examples::
    <examples>/api/cpp/sets.cpp
    <examples>/api/java/Sets.java
    <examples>/api/python/pythonic/sets.py
    <examples>/api/python/sets.py
    <examples>/api/smtlib/sets.smt2
