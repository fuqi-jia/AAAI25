DatatypeDecl
============

.. doxygenclass:: cvc5::DatatypeDecl
    :project: cvc5
    :members:
    :undoc-members:
