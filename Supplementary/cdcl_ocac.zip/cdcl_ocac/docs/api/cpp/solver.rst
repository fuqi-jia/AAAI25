Solver
======

.. doxygenclass:: cvc5::Solver
    :project: cvc5
    :members:
    :undoc-members:
