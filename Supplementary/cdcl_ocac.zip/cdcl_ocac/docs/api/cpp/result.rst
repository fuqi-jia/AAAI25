Result
======

.. doxygenclass:: cvc5::Result
    :project: cvc5
    :members:
    :undoc-members:
