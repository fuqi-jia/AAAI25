DatatypeConstructorDecl
=======================

.. doxygenclass:: cvc5::DatatypeConstructorDecl
    :project: cvc5
    :members:
    :undoc-members:
