DatatypeSelector
================

.. doxygenclass:: cvc5::DatatypeSelector
    :project: cvc5
    :members:
    :undoc-members:
