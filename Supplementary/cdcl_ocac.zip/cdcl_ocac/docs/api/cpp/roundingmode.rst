RoundingMode
============

.. doxygenenum:: cvc5::RoundingMode
    :project: cvc5
