Datatype
========

.. doxygenclass:: cvc5::Datatype
    :project: cvc5
    :members:
    :undoc-members:
