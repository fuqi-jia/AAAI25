OptionInfo
==========

.. doxygenstruct:: cvc5::OptionInfo
    :project: cvc5
    :members:
