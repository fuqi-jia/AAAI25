DatatypeConstructor
===================

.. doxygenclass:: cvc5::DatatypeConstructor
    :project: cvc5
    :members:
    :undoc-members:
