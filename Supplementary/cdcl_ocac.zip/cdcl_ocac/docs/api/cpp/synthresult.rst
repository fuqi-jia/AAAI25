SynthResult
===========

.. doxygenclass:: cvc5::SynthResult
    :project: cvc5
    :members:
    :undoc-members:
