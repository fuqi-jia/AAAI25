Op
==

.. doxygenclass:: cvc5::Op
    :project: cvc5
    :members:

.. doxygenstruct:: std::hash< cvc5::Op >
    :project: std
    :members:
    :undoc-members:
