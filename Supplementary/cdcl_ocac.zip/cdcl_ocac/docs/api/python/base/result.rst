Result
================

.. autoclass:: cvc5.Result
    :members:
    :undoc-members:
