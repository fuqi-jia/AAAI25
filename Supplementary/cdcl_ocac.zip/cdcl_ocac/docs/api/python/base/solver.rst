Solver
========

.. autoclass:: cvc5.Solver
    :members:
    :undoc-members:
