RoundingMode
================

.. autoclass:: cvc5.RoundingMode
    :members:
    :undoc-members:
