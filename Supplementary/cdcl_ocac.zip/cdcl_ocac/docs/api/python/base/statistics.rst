Statistics
==========

.. autoclass:: cvc5.Statistics
    :members:
    :special-members: __getitem__
    :undoc-members:
