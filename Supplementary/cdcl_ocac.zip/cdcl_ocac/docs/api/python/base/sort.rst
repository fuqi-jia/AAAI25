Sort
================

.. autoclass:: cvc5.Sort
    :members:
    :undoc-members:
