UnknownExplanation
==================

.. autoclass:: cvc5.UnknownExplanation
    :members:
    :undoc-members:
