DatatypeDecl
============

.. autoclass:: cvc5.DatatypeDecl
    :members:
    :undoc-members:
