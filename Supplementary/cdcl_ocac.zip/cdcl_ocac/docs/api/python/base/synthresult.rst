SynthResult
===========

.. autoclass:: cvc5.SynthResult
    :members:
    :undoc-members:
