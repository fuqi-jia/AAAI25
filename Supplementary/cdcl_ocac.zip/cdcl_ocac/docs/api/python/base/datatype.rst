Datatype
========

.. autoclass:: cvc5.Datatype
    :members:
    :special-members: __getitem__, __iter__
    :undoc-members:
