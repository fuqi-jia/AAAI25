Op
================

.. autoclass:: cvc5.Op
    :members:
    :special-members: __getitem__
    :undoc-members:
