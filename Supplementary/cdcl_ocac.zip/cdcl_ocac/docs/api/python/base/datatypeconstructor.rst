DatatypeConstructor
===================

.. autoclass:: cvc5.DatatypeConstructor
    :members:
    :special-members: __getitem__, __iter__
    :undoc-members:
