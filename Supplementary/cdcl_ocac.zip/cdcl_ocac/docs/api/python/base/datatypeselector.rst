DatatypeSelector
================

.. autoclass:: cvc5.DatatypeSelector
    :members:
    :undoc-members:
