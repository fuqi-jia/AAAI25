Term
================

.. autoclass:: cvc5.Term
    :members:
    :special-members: __getitem__, __iter__
    :undoc-members:
