DatatypeConstructorDecl
=======================

.. autoclass:: cvc5.DatatypeConstructorDecl
    :members:
    :undoc-members:
