Internals
============


Testers
-------------------
.. autofunction:: cvc5.pythonic.is_expr
.. autofunction:: cvc5.pythonic.is_sort
.. autofunction:: cvc5.pythonic.is_app
.. autofunction:: cvc5.pythonic.is_app_of

Exceptions
-------------------

.. autoclass:: cvc5.pythonic.SMTException
   :members:
   :special-members:
