Quantifiers
============

Builders
------------------
.. autofunction:: cvc5.pythonic.ForAll
.. autofunction:: cvc5.pythonic.Exists
.. autofunction:: cvc5.pythonic.Lambda

Testers
-------------------
.. autofunction:: cvc5.pythonic.is_var
.. autofunction:: cvc5.pythonic.is_quantifier

Classes
-------
.. autoclass:: cvc5.pythonic.QuantifierRef
   :members:
   :special-members:

