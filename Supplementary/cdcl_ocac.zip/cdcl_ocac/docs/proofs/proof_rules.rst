Proof rules
===========

.. doxygenenum:: cvc5::internal::PfRule
    :project: cvc5
