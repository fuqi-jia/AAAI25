Output tags
===========

cvc5 supports printing information about certain aspects of the solving process
that is intended for regular users. This feature can be enabled using the
:ref:`output <lbl-option-output>` option.

The following output tags are currently supported:

.. include-build-file:: output_tags_generated.rst
