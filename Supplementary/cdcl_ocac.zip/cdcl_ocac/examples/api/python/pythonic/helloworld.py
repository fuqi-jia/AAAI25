from cvc5.pythonic import *

if __name__ == '__main__':
    var = Bool('Hello World!')
    solve(var)
